# Pytron

This program is a simple python game, made for implementing your own AIs.

![Screenshot of the game](https://gitea.tforgione.fr/attachments/3cf5eafe-662b-4f8e-b891-c66af9b5d828)

[You can go to the wiki to have more information.](/tforgione/pytron/wiki/Home)


